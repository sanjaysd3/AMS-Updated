package com.ams.dao;

import com.ams.bean.Request;

public interface IAssetDao {

	int storeRaisedRequest(Request req);

}
