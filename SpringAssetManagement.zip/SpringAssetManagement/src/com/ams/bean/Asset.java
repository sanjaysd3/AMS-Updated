package com.ams.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="asset")
public class Asset {

		@Id
		@GeneratedValue
		@Column(name="AssetId")
		private int assetId;
		@Column(name="AssetName")
		private String assetName;
		@Column(name="AssetDes")
		private String assetDescription;
		@Column(name="Quantity")
		private int assetQuantity;
		@Column(name="Status")
		private String assetStatus;
		
		public Asset() {
			
		}

		public Asset(int assetId, String assetName, String assetDescription,
				int assetQuantity, String assetStatus) {
			super();
			this.assetId = assetId;
			this.assetName = assetName;
			this.assetDescription = assetDescription;
			this.assetQuantity = assetQuantity;
			this.assetStatus = assetStatus;
		}

		public int getAssetId() {
			return assetId;
		}

		public void setAssetId(int assetId) {
			this.assetId = assetId;
		}

		public String getAssetName() {
			return assetName;
		}

		public void setAssetName(String assetName) {
			this.assetName = assetName;
		}

		public String getAssetDescription() {
			return assetDescription;
		}

		public void setAssetDescription(String assetDescription) {
			this.assetDescription = assetDescription;
		}

		public int getAssetQuantity() {
			return assetQuantity;
		}

		public void setAssetQuantity(int assetQuantity) {
			this.assetQuantity = assetQuantity;
		}

		public String getAssetStatus() {
			return assetStatus;
		}

		public void setAssetStatus(String assetStatus) {
			this.assetStatus = assetStatus;
		}

		@Override
		public String toString() {
			return "Asset [assetId=" + assetId + ", assetName=" + assetName
					+ ", assetDescription=" + assetDescription
					+ ", assetQuantity=" + assetQuantity + ", assetStatus="
					+ assetStatus + "]";
		}
		
		
}
