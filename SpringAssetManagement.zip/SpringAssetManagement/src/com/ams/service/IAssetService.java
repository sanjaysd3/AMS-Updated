package com.ams.service;

import com.ams.bean.Request;

public interface IAssetService {

	int storeRaisedRequest(Request req);

}
